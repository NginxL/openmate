"""The hub's HTTP API, with the scoped token the hub gives the extension (initialize hub.url / hub.token, or the
environment's PERSONA_HUB_URL / PERSONA_HUB_TOKEN). Only the routes /agent needs, each under the scope the manifest
asks for (docs/extensions/extensions.md "Hub API: scopes"):

    assistant.ask   POST /api/v1/assistant/conversations, POST …/conversations/{id}/stop,
                    GET  /api/v1/assistant/reporters (a reporting conversation stopped at the hub)
    agents.control  POST /api/v1/sessions/{mid}/{sid}/messages (a conversation's, or a task's Agent's), …/interrupt
    agents.read     GET  /api/v1/sessions/{mid}/{sid}/items, …/items/{item}/full,
                    GET  /api/v1/sessions?machine_id=&session_id= (the session's status),
                    GET  /api/v1/interactions, …/interactions/history (the questions waiting now, and how one
                    ended: the 渠道 takes back one answered elsewhere)
    kb.read         GET  /api/v1/kb/chats/{id}/context
    inbox.read      GET  /api/v1/inbox (the 今天 page)
    todos.read      GET  /api/v1/todos (the 今天 page; /agent: the open task its conversation handed out)
    (none)          GET  /api/v1/health, the hub's one route without authentication: is the hub reachable now?

The manager relays these to the hub. While its bus connection is down it answers 503 manager_offline (nothing was sent);
when the request to the hub breaks it answers 502 hub_unreachable, and the hub may or may not have got it.
"""

from __future__ import annotations

import http.client
import json
import socket
import urllib.error
import urllib.parse
import urllib.request
from typing import Any, Dict, List, Optional

_LOOPBACK = {"127.0.0.1", "localhost", "::1", "[::1]"}


# Codes for failures on this side of the relay (status 0): the connection was refused, so nothing was sent; or it
# broke or timed out after it was made, so the request may have arrived.
NOT_CONNECTED = "not_connected"
NETWORK = "network"

UNSENT = ("manager_offline", "assistant_offline", NOT_CONNECTED)  # assistant_offline: nothing reached it
UNREACHABLE = UNSENT + ("hub_unreachable", NETWORK)  # the hub itself was not reached
# The hub's answers for a call to a machine that broke or timed out on the way (apierr.Call): it may have run.
MACHINE_UNSURE = ("node_unreachable", "timeout")


class HubError(Exception):
    def __init__(self, status: int, message: str, code: str = "", retryable: Optional[bool] = None,
                 delivered: str = ""):
        super().__init__(message)
        self.status = status
        self.message = message
        self.code = code
        self.retryable = retryable  # the hub's "retryable" and "delivered" ("none": nothing ran), when it said them
        self.delivered = delivered

    @property
    def unreachable(self) -> bool:
        """The hub could not be reached (a network failure, not the hub's answer)."""
        return self.code in UNREACHABLE

    @property
    def unsent(self) -> bool:
        """Nothing ran: it never reached the hub, or the hub says nothing ran and it may be tried again (the machine
        is offline). Sending it again cannot do it twice."""
        return self.code in UNSENT or (self.delivered == "none" and self.retryable is True)

    @property
    def transient(self) -> bool:
        """A network failure on the way (to the hub, or from the hub to the machine): it may work a little later.
        Unless unsent, it may also have run."""
        return self.unsent or self.unreachable or (self.code in MACHINE_UNSURE and self.status >= 500)


class HubAPI:
    def __init__(self, base_url: str, token: str, timeout: float = 30.0):
        self.base = (base_url or "").rstrip("/")
        self.token = token or ""
        self.timeout = timeout
        host = urllib.parse.urlsplit(self.base).hostname or ""
        handlers = []
        if host in _LOOPBACK:  # the hub on this machine: never through a proxy
            handlers.append(urllib.request.ProxyHandler({}))
        self._opener = urllib.request.build_opener(*handlers)

    @property
    def available(self) -> bool:
        return bool(self.base and self.token)

    def request(self, method: str, path: str, body: Optional[dict] = None, query: Optional[Dict[str, Any]] = None,
                timeout: Optional[float] = None, op_id: str = "") -> Any:
        if not self.available:
            raise HubError(0, "没有 Persona hub 的地址或令牌")
        url = self.base + path
        if query:
            url += "?" + urllib.parse.urlencode({k: v for k, v in query.items() if v is not None})
        data = None
        # the hub words its errors in the request's language; they are shown in the chat
        headers = {"Authorization": "Bearer " + self.token, "Accept": "application/json", "Accept-Language": "zh-CN"}
        if body is not None:
            data = json.dumps(body, ensure_ascii=False).encode("utf-8")
            headers["Content-Type"] = "application/json"
        if op_id:
            headers["X-Persona-Op-Id"] = op_id  # one operation however often it is sent (docs: "Operation receipts")
        req = urllib.request.Request(url, data=data, method=method, headers=headers)
        try:
            with self._opener.open(req, timeout=timeout or self.timeout) as resp:
                raw = resp.read()
        except urllib.error.HTTPError as e:
            raw = b""
            cut = False
            try:
                raw = e.read()
            except Exception:
                cut = True  # the answer broke off: what it said is not known
            finally:
                e.close()
            if cut:
                raise HubError(e.code, "和 Persona hub 的连接中途断了（HTTP %d）" % e.code, NETWORK)
            message, code, retryable, delivered = "", "", None, ""
            try:
                doc = json.loads(raw or b"{}")
                if isinstance(doc, dict):
                    message = str(doc.get("error") or doc.get("message") or "")
                    code = str(doc.get("code") or "")
                    if isinstance(doc.get("retryable"), bool):
                        retryable = doc["retryable"]
                    delivered = str(doc.get("delivered") or "")
                    if not code and str(doc.get("state") or "") in ("pending", "unknown"):
                        code = str(doc["state"])  # a receipt the hub could not settle (503 state unknown)
            except ValueError:
                pass
            raise HubError(e.code, message or ("hub 回答 HTTP %d" % e.code), code, retryable, delivered)
        except http.client.HTTPException as e:  # cut off mid-answer (IncompleteRead, a bad status line): it may have run
            raise HubError(0, "和 Persona hub 的连接中途断了（%s）" % type(e).__name__, NETWORK)
        except (urllib.error.URLError, OSError) as e:
            cause = getattr(e, "reason", e) if isinstance(e, urllib.error.URLError) else e
            refused = isinstance(cause, (ConnectionRefusedError, socket.gaierror))  # not connected: nothing was sent
            raise HubError(0, "连不上 Persona hub（%s）" % type(cause).__name__, NOT_CONNECTED if refused else NETWORK)
        if not raw:
            return {}
        try:
            return json.loads(raw)
        except ValueError:
            raise HubError(0, "hub 的回答不是 JSON")

    # ---- the routes ----

    def health(self, timeout: float = 10.0) -> None:
        """Raises HubError unless the hub answers now."""
        self.request("GET", "/api/v1/health", timeout=timeout)

    def capabilities(self) -> dict:
        """What the assistant offers ({"guest_conversations": true}); {} from a hub that doesn't say (404)."""
        try:
            return self.request("GET", "/api/v1/assistant/capabilities", timeout=15) or {}
        except HubError as e:
            if e.status == 404:
                return {}
            raise

    def start_conversation(self, prompt: str, purpose: str, report_tasks: bool, machine_id: str = "", launcher: str = "",
                           guest_tools: Optional[List[str]] = None, op_id: str = "") -> dict:
        """A conversation; with guest_tools a guest one (docs/assistant/assistant.md "Guest conversations"): it answers
        someone else for the user, with none of the assistant's powers but these connector tools. With op_id the hub
        starts it once however often it is asked (assistant_start_ops): the same op_id and body get the first answer.
        HubError code "pending": that start is still under way (ask again); "unknown": nobody can tell whether it
        started (never ask again on your own)."""
        body: Dict[str, Any] = {"prompt": prompt, "purpose": purpose, "report_tasks": bool(report_tasks)}
        if guest_tools:
            body["guest"] = {"tools": list(guest_tools)}
        if machine_id:
            body["machine_id"] = machine_id
        if launcher:
            body["launcher"] = launcher
        out = self.request("POST", "/api/v1/assistant/conversations", body, timeout=120, op_id=op_id)
        state = str((out or {}).get("state") or "") if isinstance(out, dict) else ""
        if state in ("pending", "unknown") and not (out or {}).get("session"):
            raise HubError(202, "hub 还在处理这次启动" if state == "pending" else "hub 不确定这次有没有启动", state)
        sess = (out or {}).get("session") or {}
        if not sess.get("session_id"):
            raise HubError(0, "hub 没有给出会话 id")
        return sess

    def send_message(self, machine_id: str, session_id: str, text: str, client_msg_id: str = "") -> dict:
        body: Dict[str, Any] = {"text": text}
        if client_msg_id:
            body["client_msg_id"] = client_msg_id
        return self.request("POST", "/api/v1/sessions/%s/%s/messages" % (_seg(machine_id), _seg(session_id)), body, timeout=120)

    def items(self, machine_id: str, session_id: str, after_seq: Optional[int] = None) -> dict:
        query = {"after_seq": after_seq} if after_seq is not None else {"turns": 1}
        return self.request("GET", "/api/v1/sessions/%s/%s/items" % (_seg(machine_id), _seg(session_id)), query=query)

    def item_full(self, machine_id: str, session_id: str, item_id: str) -> dict:
        return self.request("GET", "/api/v1/sessions/%s/%s/items/%s/full" % (_seg(machine_id), _seg(session_id), _seg(item_id)))

    def session_row(self, machine_id: str, session_id: str) -> Optional[dict]:
        """The session's row in the session list (status, state, updated_at), None when the list has no such row."""
        res = self.request("GET", "/api/v1/sessions", query={"machine_id": machine_id, "session_id": session_id,
                                                             "summary": 1, "limit": 1}, timeout=15) or {}
        for row in res.get("sessions") or []:
            if isinstance(row, dict) and row.get("session_id") == session_id:
                return row
        return None

    def todos(self) -> List[dict]:
        """Every to-do, as the hub lists them (`origin`: the conversation that handed it out; `done_at`; `agents`)."""
        res = self.request("GET", "/api/v1/todos", timeout=10) or {}  # optional: a slow answer asks the conversation
        return [t for t in (res.get("todos") or []) if isinstance(t, dict)] if isinstance(res, dict) else []

    def reporter_state(self, session_id: str) -> str:
        """Whether the hub tells the conversation about the tasks it opened: "reporting"; "stopped" (its task notices
        are dropped until it is asked again); "absent" (not, or no more, a reporting conversation: they go to the main
        conversation); "unknown" from a hub without the list (404)."""
        try:
            res = self.request("GET", "/api/v1/assistant/reporters", timeout=15) or {}
        except HubError as e:
            if e.status == 404:
                return "unknown"
            raise
        for r in (res.get("reporters") or []) if isinstance(res, dict) else []:
            if isinstance(r, dict) and r.get("session_id") == session_id:
                return "stopped" if r.get("stopped_at") else "reporting"
        return "absent"

    def stop_conversation(self, session_id: str) -> dict:
        return self.request("POST", "/api/v1/assistant/conversations/%s/stop" % _seg(session_id), {})

    def interrupt(self, machine_id: str, session_id: str) -> dict:
        return self.request("POST", "/api/v1/sessions/%s/%s/interrupt" % (_seg(machine_id), _seg(session_id)), {})

    def pending_interactions(self) -> List[dict]:
        """The questions and approvals waiting for an answer now (those the hub shows extensions), each with its id."""
        doc = self.request("GET", "/api/v1/interactions", timeout=15)
        items = doc.get("interactions") if isinstance(doc, dict) else None
        if not isinstance(items, list):
            raise HubError(0, "Persona hub 的待答列表看不懂", NETWORK)
        return [i for i in items if isinstance(i, dict) and i.get("id")]

    def interaction_history(self, machine_id: str, session_id: str, since: str, before: str = "", before_id: str = "",
                            limit: int = 200) -> tuple:
        """How a session's questions raised since then ended, the newest first, one page: ([{interaction: {id, …},
        status}, …], the next older page's (before, before_id), or ("", "") when this was the last)."""
        q = {"machine_id": machine_id, "session_id": session_id, "since": since, "limit": limit}
        if before:
            q.update(before=before, before_id=before_id)
        doc = self.request("GET", "/api/v1/interactions/history", query=q, timeout=15)
        items = doc.get("interactions") if isinstance(doc, dict) else None
        if not isinstance(items, list):
            raise HubError(0, "Persona hub 的问题记录看不懂", NETWORK)
        recs = [i for i in items if isinstance(i, dict) and isinstance(i.get("interaction"), dict)]
        return recs, (str(doc.get("next_before") or ""), str(doc.get("next_before_id") or ""))

    def kb_chat_context(self, kb_chat_id: str) -> Optional[dict]:
        try:
            return self.request("GET", "/api/v1/kb/chats/%s/context" % _seg(kb_chat_id), timeout=15)
        except HubError as e:
            if e.status == 404:
                return None
            raise


def _seg(s: str) -> str:
    return urllib.parse.quote(str(s), safe="")
